//
//  ViewController.swift
//  Syracuse-Bus-ProjectV2
//
//  Created by Brian  Giusti on 3/7/20.
//  Copyright © 2020 Brian  Giusti. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

