//
//  ViewController.swift
//  BusU2.0
//
//  Created by Taisei Hashimoto on 2/23/20.
//  Copyright © 2020 Taisei Hashimoto. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

